package com.example.helloJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
