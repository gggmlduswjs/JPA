package com.acorn.boardJPASimple;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardJpaSimpleApplicationTests {

	@Test
	void contextLoads() {
	}

}
