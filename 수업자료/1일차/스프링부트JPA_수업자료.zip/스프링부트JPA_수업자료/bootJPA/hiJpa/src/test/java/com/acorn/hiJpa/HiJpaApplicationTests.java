package com.acorn.hiJpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HiJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
