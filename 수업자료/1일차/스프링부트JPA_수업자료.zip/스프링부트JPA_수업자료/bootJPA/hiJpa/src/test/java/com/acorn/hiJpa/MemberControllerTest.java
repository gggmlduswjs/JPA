package com.acorn.hiJpa;

import static org.junit.jupiter.api.Assertions.*;

class MemberControllerTest {

}