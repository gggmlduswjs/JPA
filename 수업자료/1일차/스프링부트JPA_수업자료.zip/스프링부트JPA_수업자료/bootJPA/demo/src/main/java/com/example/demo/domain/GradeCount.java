package com.example.demo.domain;

public interface GradeCount {
    String getGrade();
    Long getCount();
}
