package com.example.queryDSL1222;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Data
public class GradeCountDto {
    private String grade;
    private Long count;



}
