package com.example.queryDSL1222;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QueryDsl1222Application {

	public static void main(String[] args) {
		SpringApplication.run(QueryDsl1222Application.class, args);
	}

}
