package com.example.helloJPA.optional;

public class MemberOptionalTest {
    public static void main(String[] args) {
        MemberService service = new MemberService();

        // 존재하는 회원
        System.out.println(service.getMemberName("hong@test.com")); // 홍길동

        // 존재하지 않는 회원
        System.out.println(service.getMemberName("abc@test.com")); // 기본 이름

        // Optional 활용 예시
        service.findByEmail("kim@test.com").ifPresent(m -> {
            System.out.println("찾은 회원: " + m.getName());
        }  );


        /*
        Member member = service.findByEmail("kim@test.com")
                .orElse(new Member(0L, "기본 회원", "default@test.com"));
        System.out.println("회원 이름: " + member.getName());

        */


        /*
        try {
            Member member2 = service.findByEmail("kim@test.com")
                    .orElseThrow(() -> new RuntimeException("회원이 존재하지 않습니다"));
            System.out.println("회원 이름: " + member2.getName());
        } catch (RuntimeException e) {
            System.out.println(e.getMessage());
        }
   */

        // 회원 삭제
        boolean deleted = service.deleteMember("kim@test.com");
        System.out.println("삭제 성공: " + deleted);

        // 삭제 후 조회
        System.out.println(service.getMemberName("kim@test.com")); // 기본 이름
    }
}
