package com.example.helloJPA.optional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MemberService {

    private final List<Member> members = new ArrayList<>();

    // 초기 데이터 삽입
    public MemberService() {
        members.add(new Member(1L, "홍길동", "hong@test.com"));
        members.add(new Member(2L, "김철수", "kim@test.com"));
    }

    // 이메일로 조회
    public Optional<Member> findByEmail(String email) {
        return members.stream()
                .filter(m -> m.getEmail().equals(email))
                .findFirst();
    }

    // 회원 이름 가져오기
    public String getMemberName(String email) {
        return findByEmail(email)
                .map(Member::getName)                // 값이 있으면 이름 반환
                .orElse("기본 이름");                // 없으면 기본값 반환
    }

    // 회원 추가
    public void addMember(Member member) {
        members.add(member);
    }

    // 회원 삭제
    public boolean deleteMember(String email) {
        Optional<Member> memberOpt = findByEmail(email);
        memberOpt.ifPresent(members::remove);
        return memberOpt.isPresent();
    }
}
